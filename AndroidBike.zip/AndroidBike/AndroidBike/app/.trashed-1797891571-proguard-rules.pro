# Keep notification listener service
-keep class pl.androidbike.cockpit.BikeNotificationListenerService { *; }
