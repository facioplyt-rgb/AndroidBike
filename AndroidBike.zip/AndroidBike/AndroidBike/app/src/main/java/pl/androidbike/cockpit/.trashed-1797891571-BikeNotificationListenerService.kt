package pl.androidbike.cockpit

import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.Locale

class BikeNotificationListenerService : NotificationListenerService() {

    private var sessionManager: MediaSessionManager? = null

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { controllers ->
            updateFromControllers(controllers)
        }

    override fun onListenerConnected() {
        super.onListenerConnected()
        try {
            sessionManager =
                getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val component = ComponentName(this, BikeNotificationListenerService::class.java)
            sessionManager?.addOnActiveSessionsChangedListener(sessionsListener, component)
            updateFromControllers(sessionManager?.getActiveSessions(component))
        } catch (_: Exception) {
        }

        try {
            activeNotifications?.forEach { parseNotification(it) }
        } catch (_: Exception) {
        }
    }

    override fun onListenerDisconnected() {
        try {
            sessionManager?.removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (_: Exception) {
        }
        BikeDataBus.activeMediaController = null
        super.onListenerDisconnected()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn != null) {
            parseNotification(sbn)
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        if (sbn?.packageName == "com.google.android.apps.maps") {
            BikeDataBus.updateNav(NavState())
        }
    }

    private fun updateFromControllers(controllers: List<MediaController>?) {
        if (controllers.isNullOrEmpty()) return
        val preferred = controllers.firstOrNull { it.packageName == "com.spotify.music" }
            ?: controllers.first()

        BikeDataBus.activeMediaController = preferred
        val meta = preferred.metadata
        val title = meta?.getString(MediaMetadata.METADATA_KEY_TITLE)
        val artist = meta?.getString(MediaMetadata.METADATA_KEY_ARTIST)
        val playing = preferred.playbackState?.state == PlaybackState.STATE_PLAYING

        if (!title.isNullOrBlank()) {
            BikeDataBus.updateMedia(
                MediaState(
                    title = title,
                    artist = artist ?: "Spotify",
                    isPlaying = playing
                )
            )
        }
    }

    private fun parseNotification(sbn: StatusBarNotification) {
        val extras = sbn.notification?.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.trim().orEmpty()
        val subText = extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString()?.trim().orEmpty()

        when (sbn.packageName) {
            "com.google.android.apps.maps" -> {
                val combined = listOf(title, text, bigText, subText)
                    .filter { it.isNotEmpty() }
                    .joinToString(" • ")

                if (combined.isNotEmpty()) {
                    val distanceText = when {
                        title.any { it.isDigit() } -> title
                        subText.any { it.isDigit() } -> subText
                        else -> "NAWIGACJA AKTYWNA"
                    }
                    val instructionText = when {
                        bigText.isNotEmpty() && bigText != distanceText -> bigText
                        text.isNotEmpty() && text != distanceText -> text
                        else -> combined
                    }
                    val arrow = detectDirectionArrow(combined)
                    BikeDataBus.updateNav(
                        NavState(
                            arrow = arrow,
                            distance = distanceText,
                            instruction = instructionText
                        )
                    )
                }
            }

            "com.spotify.music" -> {
                if (title.isNotEmpty()) {
                    BikeDataBus.updateMedia(
                        MediaState(
                            title = title,
                            artist = text.ifEmpty { "Spotify" },
                            isPlaying = true
                        )
                    )
                }
            }
        }
    }

    private fun detectDirectionArrow(rawText: String): String {
        val lower = rawText.lowercase(Locale.getDefault())
        return when {
            lower.contains("zawróć") || lower.contains("u-turn") -> "↶"
            lower.contains("rondo") || lower.contains("roundabout") -> "↻"
            lower.contains("ostro w prawo") || lower.contains("sharp right") -> "↱"
            lower.contains("ostro w lewo") || lower.contains("sharp left") -> "↰"
            lower.contains("w prawo") || lower.contains("right") -> "↱"
            lower.contains("w lewo") || lower.contains("left") -> "↰"
            lower.contains("cel") || lower.contains("destination") -> "🏁"
            else -> "↑"
        }
    }
}
