package pl.androidbike.cockpit

import android.content.Context
import android.media.AudioManager
import android.media.session.MediaController
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent

data class NavState(
    val arrow: String = "↑",
    val distance: String = "BRAK AKTYWNEJ TRASY",
    val instruction: String = "Uruchom trasę w Mapach Google, aby widzieć skręty"
)

data class MediaState(
    val title: String = "Spotify — brak odtwarzania",
    val artist: String = "Uruchom muzykę w Spotify",
    val isPlaying: Boolean = false
)

object BikeDataBus {
    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile
    var currentNav = NavState()
        private set

    @Volatile
    var currentMedia = MediaState()
        private set

    @Volatile
    var activeMediaController: MediaController? = null

    var onNavUpdated: ((NavState) -> Unit)? = null
    var onMediaUpdated: ((MediaState) -> Unit)? = null

    fun updateNav(state: NavState) {
        currentNav = state
        mainHandler.post {
            onNavUpdated?.invoke(state)
        }
    }

    fun updateMedia(state: MediaState) {
        currentMedia = state
        mainHandler.post {
            onMediaUpdated?.invoke(state)
        }
    }

    fun sendMediaCommand(context: Context, keyCode: Int) {
        val controller = activeMediaController
        if (controller != null) {
            val controls = controller.transportControls
            when (keyCode) {
                KeyEvent.KEYCODE_MEDIA_NEXT -> controls.skipToNext()
                KeyEvent.KEYCODE_MEDIA_PREVIOUS -> controls.skipToPrevious()
                KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                    val state = controller.playbackState?.state
                    if (state == android.media.session.PlaybackState.STATE_PLAYING) {
                        controls.pause()
                    } else {
                        controls.play()
                    }
                }
            }
            return
        }

        // Awaryjne wyslanie przycisku multimedialnego w systemie Android
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audioManager.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
        audioManager.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
    }
}
