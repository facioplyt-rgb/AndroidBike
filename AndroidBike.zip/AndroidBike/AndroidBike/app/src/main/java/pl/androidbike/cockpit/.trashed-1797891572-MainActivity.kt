package pl.androidbike.cockpit

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationManagerCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.sin

class MainActivity : AppCompatActivity(), LocationListener {

    private lateinit var tvClock: TextView
    private lateinit var tvGpsStatus: TextView
    private lateinit var btnTestMode: Button
    private lateinit var btnEnableNotifications: Button

    private lateinit var tvNavArrow: TextView
    private lateinit var tvNavDistance: TextView
    private lateinit var tvNavInstruction: TextView

    private lateinit var tvSpeed: TextView
    private lateinit var tvDistance: TextView
    private lateinit var tvTime: TextView
    private lateinit var tvAvgMax: TextView
    private lateinit var btnStartPause: Button
    private lateinit var btnReset: Button

    private lateinit var tvTrackTitle: TextView
    private lateinit var tvTrackArtist: TextView
    private lateinit var btnPrev: Button
    private lateinit var btnPlayPause: Button
    private lateinit var btnNext: Button
    private lateinit var btnVolDown: Button
    private lateinit var tvVolume: TextView
    private lateinit var btnVolUp: Button

    private lateinit var btnOpenMaps: Button
    private lateinit var btnOpenSpotify: Button

    private lateinit var locationManager: LocationManager
    private lateinit var audioManager: AudioManager

    private val handler = Handler(Looper.getMainLooper())
    private var isRiding = false
    private var isTestMode = false

    private var elapsedSeconds = 0L
    private var totalDistanceMeters = 0.0
    private var maxSpeedKmh = 0.0f
    private var lastLocation: Location? = null
    private var simTick = 0

    private val clockFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

    private val tickerRunnable = object : Runnable {
        override fun run() {
            tvClock.text = clockFormat.format(Date())
            updateVolumeDisplay()

            if (isRiding) {
                elapsedSeconds++
                if (isTestMode) {
                    runSimulationStep()
                }
                updateTripStatsUI()
            }
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)

        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager

        bindViews()
        setupListeners()
        bindDataBus()
        checkLocationPermissionAndStartGps()

        handler.post(tickerRunnable)
    }

    override fun onResume() {
        super.onResume()
        val hasNotifAccess =
            NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
        btnEnableNotifications.visibility = if (hasNotifAccess) View.GONE else View.VISIBLE
        updateNavUI(BikeDataBus.currentNav)
        updateMediaUI(BikeDataBus.currentMedia)
    }

    override fun onDestroy() {
        handler.removeCallbacks(tickerRunnable)
        BikeDataBus.onNavUpdated = null
        BikeDataBus.onMediaUpdated = null
        try {
            locationManager.removeUpdates(this)
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    private fun bindViews() {
        tvClock = findViewById(R.id.tvClock)
        tvGpsStatus = findViewById(R.id.tvGpsStatus)
        btnTestMode = findViewById(R.id.btnTestMode)
        btnEnableNotifications = findViewById(R.id.btnEnableNotifications)

        tvNavArrow = findViewById(R.id.tvNavArrow)
        tvNavDistance = findViewById(R.id.tvNavDistance)
        tvNavInstruction = findViewById(R.id.tvNavInstruction)

        tvSpeed = findViewById(R.id.tvSpeed)
        tvDistance = findViewById(R.id.tvDistance)
        tvTime = findViewById(R.id.tvTime)
        tvAvgMax = findViewById(R.id.tvAvgMax)
        btnStartPause = findViewById(R.id.btnStartPause)
        btnReset = findViewById(R.id.btnReset)

        tvTrackTitle = findViewById(R.id.tvTrackTitle)
        tvTrackArtist = findViewById(R.id.tvTrackArtist)
        btnPrev = findViewById(R.id.btnPrev)
        btnPlayPause = findViewById(R.id.btnPlayPause)
        btnNext = findViewById(R.id.btnNext)
        btnVolDown = findViewById(R.id.btnVolDown)
        tvVolume = findViewById(R.id.tvVolume)
        btnVolUp = findViewById(R.id.btnVolUp)

        btnOpenMaps = findViewById(R.id.btnOpenMaps)
        btnOpenSpotify = findViewById(R.id.btnOpenSpotify)
    }

    private fun setupListeners() {
        btnEnableNotifications.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        btnTestMode.setOnClickListener {
            isTestMode = !isTestMode
            btnTestMode.text = if (isTestMode) "TEST: WŁ." else "TEST: WYŁ."
            if (isTestMode) {
                tvGpsStatus.text = "GPS: SYMULACJA"
                BikeDataBus.updateMedia(
                    MediaState(
                        title = "Blinding Lights (Symulacja)",
                        artist = "The Weeknd • Spotify",
                        isPlaying = true
                    )
                )
            } else {
                tvGpsStatus.text = "GPS: AKTYWNY"
                tvSpeed.text = "0.0"
            }
        }

        btnStartPause.setOnClickListener {
            if (!isTestMode) {
                checkLocationPermissionAndStartGps()
            }
            isRiding = !isRiding
            btnStartPause.text = if (isRiding) "PAUZA" else "WZNÓW JAZDĘ"
        }

        btnReset.setOnClickListener {
            isRiding = false
            elapsedSeconds = 0L
            totalDistanceMeters = 0.0
            maxSpeedKmh = 0.0f
            lastLocation = null
            tvSpeed.text = "0.0"
            btnStartPause.text = "START JAZDY"
            updateTripStatsUI()
        }

        btnPrev.setOnClickListener {
            BikeDataBus.sendMediaCommand(this, KeyEvent.KEYCODE_MEDIA_PREVIOUS)
        }

        btnPlayPause.setOnClickListener {
            BikeDataBus.sendMediaCommand(this, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
        }

        btnNext.setOnClickListener {
            BikeDataBus.sendMediaCommand(this, KeyEvent.KEYCODE_MEDIA_NEXT)
        }

        btnVolDown.setOnClickListener {
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, 0)
            updateVolumeDisplay()
        }

        btnVolUp.setOnClickListener {
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, 0)
            updateVolumeDisplay()
        }

        btnOpenMaps.setOnClickListener {
            launchExternalApp("com.google.android.apps.maps", "Mapy Google")
        }

        btnOpenSpotify.setOnClickListener {
            launchExternalApp("com.spotify.music", "Spotify")
        }
    }

    private fun bindDataBus() {
        BikeDataBus.onNavUpdated = { nav -> updateNavUI(nav) }
        BikeDataBus.onMediaUpdated = { media -> updateMediaUI(media) }
    }

    private fun updateNavUI(nav: NavState) {
        tvNavArrow.text = nav.arrow
        tvNavDistance.text = nav.distance
        tvNavInstruction.text = nav.instruction
    }

    private fun updateMediaUI(media: MediaState) {
        tvTrackTitle.text = media.title
        tvTrackArtist.text = media.artist
    }

    private fun updateVolumeDisplay() {
        val current = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val percent = (current * 100) / max
        tvVolume.text = "$percent%"
    }

    private fun checkLocationPermissionAndStartGps() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                101
            )
            return
        }
        try {
            locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                500L,
                0f,
                this
            )
            tvGpsStatus.text = "GPS: GOTOWY"
        } catch (_: Exception) {
            tvGpsStatus.text = "GPS: BRAK MODUŁU"
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 101 && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            checkLocationPermissionAndStartGps()
        }
    }

    override fun onLocationChanged(location: Location) {
        if (isTestMode) return

        val rawKmh = if (location.hasSpeed()) location.speed * 3.6f else 0f
        val speedKmh = if (rawKmh < 1.2f) 0f else rawKmh

        tvGpsStatus.text = "GPS: ±${location.accuracy.toInt()}m"
        tvSpeed.text = String.format(Locale.US, "%.1f", speedKmh)

        if (isRiding) {
            if (speedKmh > maxSpeedKmh) {
                maxSpeedKmh = speedKmh
            }
            val prev = lastLocation
            if (prev != null && speedKmh > 1.2f) {
                val delta = prev.distanceTo(location)
                if (delta in 0.5f..150f) {
                    totalDistanceMeters += delta
                }
            }
            updateTripStatsUI()
        }
        lastLocation = location
    }

    private fun runSimulationStep() {
        simTick++
        val simSpeed = (24.5 + 5.5 * sin(simTick * 0.25)).toFloat()
        tvSpeed.text = String.format(Locale.US, "%.1f", simSpeed)
        if (simSpeed > maxSpeedKmh) {
            maxSpeedKmh = simSpeed
        }
        totalDistanceMeters += (simSpeed / 3.6)

        when (simTick % 15) {
            1 -> updateNavUI(NavState("↱", "150 m", "Skręć w prawo w ul. Sikorskiego"))
            6 -> updateNavUI(NavState("↰", "40 m", "Skręć w lewo w ścieżkę rowerową"))
            11 -> updateNavUI(NavState("↻", "250 m", "Na rondzie zjedź 2. zjazdem"))
        }
    }

    private fun updateTripStatsUI() {
        val km = totalDistanceMeters / 1000.0
        tvDistance.text = String.format(Locale.US, "%.2f km", km)

        val hrs = elapsedSeconds / 3600
        val mins = (elapsedSeconds % 3600) / 60
        val secs = elapsedSeconds % 60
        tvTime.text = String.format(Locale.US, "%02d:%02d:%02d", hrs, mins, secs)

        val avgKmh = if (elapsedSeconds > 0) (km / (elapsedSeconds / 3600.0)) else 0.0
        tvAvgMax.text = String.format(Locale.US, "%.1f / %.1f", avgKmh, maxSpeedKmh)
    }

    private fun launchExternalApp(pkg: String, appName: String) {
        val launchIntent = packageManager.getLaunchIntentForPackage(pkg)
        if (launchIntent != null) {
            startActivity(launchIntent)
        } else {
            Toast.makeText(this, "Nie znaleziono aplikacji $appName", Toast.LENGTH_SHORT).show()
        }
    }
}
